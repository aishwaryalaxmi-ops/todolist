import java.sql.*;
import javax.swing.*;

public class todo {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Student Management");
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Name
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 30, 100, 25);
        frame.add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(150, 30, 250, 25);
        frame.add(nameField);

        // Registration Number
        JLabel regLabel = new JLabel("Reg No:");
        regLabel.setBounds(50, 70, 100, 25);
        frame.add(regLabel);

        JTextField regField = new JTextField();
        regField.setBounds(150, 70, 250, 25);
        frame.add(regField);

        // Branch
        JLabel branchLabel = new JLabel("Branch:");
        branchLabel.setBounds(50, 110, 100, 25);
        frame.add(branchLabel);

        JTextField branchField = new JTextField();
        branchField.setBounds(150, 110, 250, 25);
        frame.add(branchField);

        // Age
        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setBounds(50, 150, 100, 25);
        frame.add(ageLabel);

        JTextField ageField = new JTextField();
        ageField.setBounds(150, 150, 250, 25);
        frame.add(ageField);

        // Sex
        JLabel sexLabel = new JLabel("Sex:");
        sexLabel.setBounds(50, 190, 100, 25);
        frame.add(sexLabel);

        JTextField sexField = new JTextField();
        sexField.setBounds(150, 190, 250, 25);
        frame.add(sexField);

        // Add Button
        JButton addBtn = new JButton("Add Student");
        addBtn.setBounds(70, 230, 150, 30);
        frame.add(addBtn);

        // Fetch Button
        JButton fetchBtn = new JButton("Fetch Data");
        fetchBtn.setBounds(250, 230, 150, 30);
        frame.add(fetchBtn);

        // Text Area
        JTextArea area = new JTextArea();
        area.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(area);
        scrollPane.setBounds(50, 280, 350, 150);
        frame.add(scrollPane);

        // ADD STUDENT
        addBtn.addActionListener(e -> {

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");

                Connection con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/testb",
                        "root",
                        "qwerty@123$%"
                );

                String query =
                        "INSERT INTO students(name, regno, branch, age, sex) " +
                                "VALUES(?,?,?,?,?)";

                PreparedStatement pst = con.prepareStatement(query);

                pst.setString(1, nameField.getText());
                pst.setString(2, regField.getText());
                pst.setString(3, branchField.getText());
                pst.setInt(4, Integer.parseInt(ageField.getText()));
                pst.setString(5, sexField.getText());

                pst.executeUpdate();

                JOptionPane.showMessageDialog(
                        frame,
                        "Student Added Successfully!"
                );

                // Clear fields
                nameField.setText("");
                regField.setText("");
                branchField.setText("");
                ageField.setText("");
                sexField.setText("");

                pst.close();
                con.close();

            } catch (NumberFormatException ex) {

                JOptionPane.showMessageDialog(
                        frame,
                        "Age must be a number!"
                );

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        frame,
                        "Error: " + ex.getMessage()
                );
            }
        });

        // FETCH DATA
        fetchBtn.addActionListener(e -> {

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");

                Connection con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/testb",
                        "root",
                        "your_password"
                );

                String query = "SELECT * FROM students";

                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery(query);

                area.setText("");

                while (rs.next()) {

                    area.append(
                            "Name: " + rs.getString("name") + "\n" +
                                    "Reg No: " + rs.getString("regno") + "\n" +
                                    "Branch: " + rs.getString("branch") + "\n" +
                                    "Age: " + rs.getInt("age") + "\n" +
                                    "Sex: " + rs.getString("sex") + "\n" +
                                    "-----------------------------\n"
                    );
                }

                rs.close();
                stmt.close();
                con.close();

            } catch (Exception ex) {

                JOptionPane.showMessageDialog(
                        frame,
                        "Error: " + ex.getMessage()
                );
            }
        });

        frame.setVisible(true);
    }
}